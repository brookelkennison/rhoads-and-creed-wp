<div id="main" class-="main-content">
    <div>
	<?php 
    		get_template_part('template-parts/content/content');
    ?>
    </div>
</div>

