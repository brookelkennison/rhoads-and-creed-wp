<?php
/**
 * Displays breadcrumb
 *
 * @package Business_Capital
 */

business_capital_breadcrumb();
