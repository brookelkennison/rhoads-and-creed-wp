<?php
/**
 * Header Mobile Search
 *
 * @package Business_Capital
 */
?>
<div class="mobile-search">
	<?php get_search_form(); ?>
</div><!-- .header-search -->
